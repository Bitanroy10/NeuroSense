// Vercel serverless entry: every /api/* request is handled by the shared backend.
// (Files starting with "_" in /api are helpers, not separate endpoints.)
module.exports = require('./_server').handler;
